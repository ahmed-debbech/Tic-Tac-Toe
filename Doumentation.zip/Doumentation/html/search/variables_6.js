var searchData=
[
  ['x',['x',['../structplaygameScreen.html#a3a92251f3e07562908af17c6f10fb987',1,'playgameScreen']]],
  ['xc',['xc',['../structcomputerEnteries.html#a0c5ec18fa265d563e1b1eee195cbdf5f',1,'computerEnteries']]]
];
