var searchData=
[
  ['line',['line',['../structlines.html#a5f8e328c17e440ff0432fed248901a25',1,'lines']]],
  ['linepos',['linePos',['../structlines.html#a3380efcee41962c637b94b369a48c354',1,'lines']]]
];
