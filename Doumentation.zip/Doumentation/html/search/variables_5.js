var searchData=
[
  ['scorepos',['scorePos',['../structplaygameScreen.html#aacc9296e49733cfcf331bfd9ca12e1b9',1,'playgameScreen']]]
];
