var searchData=
[
  ['yc',['yc',['../structcomputerEnteries.html#afea2a2d63e8ec9fb3e6e21f550bb751a',1,'computerEnteries']]]
];
