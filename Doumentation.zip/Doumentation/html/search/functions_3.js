var searchData=
[
  ['managescore',['manageScore',['../core_8c.html#a2c993881faa8aa9592cdd85ba7c30bbc',1,'core.c']]],
  ['menuclicks',['menuClicks',['../graphics_8c.html#ab4d075ef8d2e3298d7039e07bd9f2054',1,'graphics.c']]],
  ['menumotion',['menuMotion',['../graphics_8c.html#a8b0d791e3f05f6d5f19858ce814e1e41',1,'graphics.c']]]
];
