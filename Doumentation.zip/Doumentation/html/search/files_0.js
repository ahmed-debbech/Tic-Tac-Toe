var searchData=
[
  ['core_2ec',['core.c',['../core_8c.html',1,'']]]
];
