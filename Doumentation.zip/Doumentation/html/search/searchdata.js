var indexSectionsWithContent =
{
  0: "abcghilmopsxy",
  1: "abchlmps",
  2: "cgm",
  3: "cgimps",
  4: "bilopsxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

