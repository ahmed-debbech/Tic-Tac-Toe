var searchData=
[
  ['getpick',['getPick',['../core_8c.html#af4dddb28209e9381835b53946f8c5a0f',1,'core.c']]]
];
