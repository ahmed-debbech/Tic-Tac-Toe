var searchData=
[
  ['pick',['pick',['../structpicker.html#a948bbcd036e117eb858dfdf0ece7ee00',1,'picker']]]
];
