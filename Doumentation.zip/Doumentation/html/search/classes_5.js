var searchData=
[
  ['menu',['menu',['../structmenu.html',1,'']]],
  ['menuofplay',['menuOfPlay',['../structmenuOfPlay.html',1,'']]],
  ['menuplaygame',['menuPlayGame',['../structmenuPlayGame.html',1,'']]]
];
