var searchData=
[
  ['player',['player',['../core_8c.html#a8380108e8abfce2895ec11e549e07754',1,'core.c']]],
  ['printontable',['printOnTable',['../core_8c.html#a03f5b5e1a362f08422079c4044b273d3',1,'core.c']]]
];
