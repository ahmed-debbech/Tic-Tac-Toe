var searchData=
[
  ['computerenteries',['computerEnteries',['../structcomputerEnteries.html',1,'']]],
  ['control',['control',['../structcontrol.html',1,'']]]
];
